
## Jouer

1. Au démarrage, vous serez invité à saisir votre nom et à choisir un niveau de difficulté (facile, moyen ou difficile).
2. Le jeu affichera une série de questions à choix multiples, une à la fois.
3. Sélectionnez votre réponse en saisissant le numéro correspondant à votre choix et appuyez sur Entrée.
4. Vous recevrez un retour immédiat sur la validité de votre réponse.
5. À la fin du jeu, votre score final sera affiché.

Amusez-vous bien !
